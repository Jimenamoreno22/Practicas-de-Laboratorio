﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_AJMR_1080723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Motocicleta objMotocicleta = new Motocicleta();
            objMotocicleta.motocicleta(2019, 1000.00, "YAMAHA", 0.12);
            
            Console.WriteLine("Los datos de su motocicleta son:");
            Console.WriteLine("");

            Console.WriteLine("Modelo: " + objMotocicleta.Modelo);
            Console.WriteLine("Precio: " + objMotocicleta.Precio);
            Console.WriteLine("Marca: " + objMotocicleta.Marca);
            Console.WriteLine("IVA: " + objMotocicleta.Iva);
            double precioiva = 1000.00 * 1.12;
            double pagoiva = precioiva - 1000.00;
            Console.WriteLine("El precio de la motocicleta sin IVA es:Q" + objMotocicleta.Precio);
            Console.WriteLine("El precio de la motocicleta con IVA es: Q" + precioiva);
            Console.WriteLine("El monto es: Q" + pagoiva);
            Console.ReadKey();
        }
    }
}