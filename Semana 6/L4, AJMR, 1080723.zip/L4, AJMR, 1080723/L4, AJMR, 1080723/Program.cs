﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L4__AJMR__1080723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicio 1: operaciones aritméticas");
            Console.WriteLine("Ingrese el primer nùmero");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo nùmero");
            int num2 = int.Parse(Console.ReadLine());
            int suma = (num1 + num2);
            double resta = (num1 - num2);
            int multiplicaciòn = (num1 * num2);
            int divisiònentera = (num1 / num2);
            int residuo = (num1 % num2);
            Console.WriteLine(num1 + "+" + num2 + "=" + suma);
            Console.WriteLine(num1 + "-" + num2 + "=" + resta);
            Console.WriteLine(num1 + "*" + num2 + "=" + multiplicaciòn);
            Console.WriteLine(num1 + "/" + num2 + "=" + ((double) num1/num2));
            Console.WriteLine(num1 + "div" + num2 + "=" + divisiònentera);
            Console.WriteLine(num1 + "mod" + num2 + "=" + residuo);
            Console.WriteLine(" ");

            Console.WriteLine("Ejercicio 2: operaciones booleanas");
            if (num1 > num2)
            {
            Console.WriteLine(num1 + ">" + num2);
            }
            if (num1 < num2)
            Console.WriteLine(num1 + "<" + num2);
            if (num1 == num2)
            Console.WriteLine(num1 + "=" + num2);
            Console.WriteLine(" ");

            Console.WriteLine("Ejercicio 3: jerarquía de operaciones");
            Console.WriteLine("Ingrese el primer nùmero");
            double a = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo nùmero");
            double b = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el tercer nùmero");
            double c = int.Parse(Console.ReadLine());
            Console.WriteLine(" ");
            double i = (a * b + c);
            double ii = (a * (b + c));
            double iii = (a / (b * c));
            double iv = ((3*a + 2*b) / (Math.Pow(c, 2 )));
            Console.WriteLine("i = " + i);
            Console.WriteLine("ii = " + ii);
            Console.WriteLine("iii = " + iii);
            Console.WriteLine("iv = " + iv);
            Console.WriteLine(" ");

            Console.WriteLine("Càlculo de ecuaciòn cuadràtica");
            double discriminante = (Math.Pow(b, 2)) - (4 * a * c);
            if (a == 0)
            Console.WriteLine("Error a no puede ser igual a cero"); 
            if (discriminante<0)
            Console.WriteLine("Error el discriminante no puede ser un nùmero negativo");
            else
            {
            double x1 = (-b + Math.Sqrt(discriminante)) / (2 * a);
            double x2 = (-b - Math.Sqrt(discriminante)) / (2 * a);
            Console.WriteLine("Las soluciones de la ecuaciòn cuadratica son:");
            Console.WriteLine("x1 = " + x1);
            Console.WriteLine("x2 = " + x2);
            }
            Console.ReadKey();

        }
    }

}
