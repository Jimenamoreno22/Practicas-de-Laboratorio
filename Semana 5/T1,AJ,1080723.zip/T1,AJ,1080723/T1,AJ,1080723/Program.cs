﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_AJ_1080723
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Ingresa tu nombre:");
            string Nombre = Console.ReadLine();
            Console.WriteLine("Ingresa tu edad:");
            string Edad = Console.ReadLine();
            Console.WriteLine("Ingresa tu carrera:");
            string Carrera = Console.ReadLine();
            Console.WriteLine("Ingresa tu carne:");
            string Carne = Console.ReadLine();

            Console.WriteLine("Mi segundo programa");
            Console.WriteLine("Nombre:" + Nombre);
            Console.WriteLine("Edad:" + Edad);
            Console.WriteLine("Carrera:" + Carrera);
            Console.WriteLine("Carne:" + Carne);

            /* COMENTARIOS */

            Console.Write("soy" +" "+ Nombre+" " + "tengo" + " " + Edad+ " " + "años y estudio la carrera de" + " " + Carrera+ ". Mi nùmero de carnè es" + " " + Carne);
            Console.ReadKey();
        }
    }
}
