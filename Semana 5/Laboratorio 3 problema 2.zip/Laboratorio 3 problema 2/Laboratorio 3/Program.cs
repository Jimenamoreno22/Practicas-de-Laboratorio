﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("El valor del automóvil comprado en 2016 es de Q100,000.00");
            Console.WriteLine("Durante los seis años siguientes el valor de recuperación es de Q50,000.00");
            int valor_original = 100000, valor_recuperado = 50000;
            Console.WriteLine("");


            int depreciacion = ((valor_original - valor_recuperado)/6);
            int depreciacion1 = ((valor_original - valor_recuperado) * 2) / 6;
            int depreciacion2 = ((valor_original - valor_recuperado) * 3) / 6;
            int depreciacion3 = ((valor_original - valor_recuperado) * 4) / 6;
            int depreciacion4 = ((valor_original - valor_recuperado) * 5) / 6;
            int depreciacion5 = ((valor_original - valor_recuperado) * 6) / 6;

            int valor_real = (100000 - depreciacion);
            int valor_real1 = (100000 - depreciacion1);
            int valor_real2 = (100000 - depreciacion2);
            int valor_real3 = (100000 - depreciacion3);
            int valor_real4 = (100000 - depreciacion4);
            int valor_real5 = (100000 - depreciacion5);

            Console.WriteLine("Las depreciaciones acumuladas durante los 6 años son:");
            Console.WriteLine("Depreciaciòn 1er año:" + depreciacion);
            Console.WriteLine("Depreciaciòn 2er año:" + depreciacion1);
            Console.WriteLine("Depreciaciòn 3er año:" + depreciacion2);
            Console.WriteLine("Depreciaciòn 4er año:" + depreciacion3);
            Console.WriteLine("Depreciaciòn 5er año:" + depreciacion4);
            Console.WriteLine("Depreciaciòn 6er año:" + depreciacion5);
            Console.WriteLine("");

            Console.WriteLine("Los valores reales durante los 6 años son:");
            Console.WriteLine("Valor real 1er año:" + valor_real);
            Console.WriteLine("Valor real 2er año:" + valor_real1);
            Console.WriteLine("Valor real 3er año:" + valor_real2);
            Console.WriteLine("Valor real 4er año:" + valor_real3);
            Console.WriteLine("Valor real 5er año:" + valor_real4);
            Console.WriteLine("Valor real 6er año:" + valor_real5);

            Console.ReadKey();

        }
    }
}
