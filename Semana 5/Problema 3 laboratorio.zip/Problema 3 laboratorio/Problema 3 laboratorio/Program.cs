﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problema_3_laboratorio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calcular la nota de una evaluaciòn");
            Console.WriteLine("Ingrese la cantidad de sus respuestas correctas");
            double respuestas_correctas = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese la cantidad de sus respuestas incorrectas");
            double respuestas_incorrectas = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese la cantidad de sus respuestas en blanco");
            double respuestas_enblanco = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("");

            double puntaje_final = (respuestas_correctas * 5) + (respuestas_incorrectas * -1) + respuestas_enblanco * 0;
            
            Console.WriteLine("Su puntaje final es de:" + puntaje_final);

            Console.ReadKey();
        }
    }
}
